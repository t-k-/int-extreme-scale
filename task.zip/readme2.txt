If you cannot complete a portion of a question, please continue to the other parts of the questions or other questions. We are interested in HOW you approach the problems more than IF you can answer them all. In all of these questions, if there are any unclear aspects, make some assumptions and tell us what they are and why you would do it that way. If you have any questions, you can feel free to email me for clarification.

Question 1 (please be as detailed as you can):
Suppose you are managing a cloud infrastructure in an organization of your choice.

* Please give a high-level description of your system's architecture. Frame your answer in terms of the layered components the system encompasses, including infrastructure, platform, and application(s).
* What information would you request from a customer in order to be able to provision an application in your cloud?
* Describe the storage infrastructure in your cloud
* Describe the (networking|communications infrastructure) in your cloud.
* Describe the steps that are taken to add a new physical node to the cloud and ready it for use in a deployed application.
* Say a customer requests a PaaS service for a web server with a local MySQL database. Describe the steps that are taken when a customer requests a set of compute resources up until the applications are ready. Start with how machines are provisioned, describe the intermediate steps, and end with the credential information and resource identifiers given to the customer.

For this question, you will need to write a script. You may use Bash, Perl or Python.  It should be able to run if typed in as a command on a normal Linux/compatible system (i.e., it should not be necessary to run `bash SCRIPT_NAME`). Ensure that the script file is formatted correctly so that this will happen. We will ensure that filesystem permissions are set correctly for the script.

Your script will rely on other "module" scripts, written in the same language as your script, each of which is a separate file that can be included in the customary fashion (i.e. Bash 'source', Perl 'use', Python 'import').  After defining any "variables" specified by the configuration file, your script will need to interact in various ways with the modules and export an interface so that those modules can access the configuration "variables".

The purpose of this Question is to allow you to demonstrate your familiarity with scripting, as well as the system tools and environmental features provided to support scripting on Linux/POSIX platforms.
You can rely on any external tools that would normally be present on a clean Linux install, including the coreutils, gawk, grep, and sed; however, try to avoid excessive dependency on external tools---prefer builtins and language-internal features where you can.

Use existing command-line tools (esp. coreutils) as a model for message formatting, and standard POSIX-platform practice for things like process exit codes and choice of output stream (e.g., stdout vs. stderr vs. external file). If you'd like to use a more specific scheme (e.g., BSD sysexits), feel free to do so, but make a note of it. Also, try to comment your script so that somebody else would be able to read your code with minimal confusion.

Command-line format:
	The script should accept only a single command-line parameter, the name of a configuration file. If the script receive more than one argument, it should print an appropriate error message and exit. If it receives no arguments, it should print a usage help message and exit.

Configuration file format:
	Each line of the configuration file has either the form
	VARIABLE_NAME : VALUE
or
	module MODULE_NAME
Normal '#' comments may be included, which begin with '#' and end at the end of the line. Empty lines should be ignored, as should whitespace between the above-described tokens. (I.e., whitespace *within* VALUE and MODULE_NAME is significant, but not whitespace at the beginning or end of the line, and not whitespace around ':' or after 'module'.) Backslashes are not significant in any way, and do not escape line ends or other special characters.

	VARIABLE_NAME must consist of one or more alphanumeric characters or underscores. (Unlike normal variable names, digits are allowed in the first position.)

	VALUE and MODULE_NAME may contain any non-line-breaking character, including medial whitespace.

Modules:
	A module is a script that can be included in the customary fashion (i.e. Bash 'source', Perl 'use', Python 'import'). Module files should be located in the "modules" subdirectory of the directory the script is in. (Note: Do not make any assumptions about the location of the main script, the "modules" directory, or what the working directory is when calling the script. You will need to find "modules" automatically at run time.) A MODULE_NAME in a configuration file line is converted to a filename by prepending the absolute pathname of the modules directory and appending an appropriate extension (i.e. ".mod.sh"); thus module name "foo" could be translated to the filename
	/usr/local/share/your_script/modules/foo.mod.sh

	Your script should make a set of functions and variables available to any modules it loads.  What follows is the API for Bash, if you chose Perl or Python you should translate/provide equivalent features in your language of choice:
	function module_begin
		Takes one argument, the name of the module.
		Returns 0 iff the module has not been loaded yet.
		Modules should call this upon entry to guard against duplicate initialization, thus:

		module_begin MODULE_NAME && {
			# MODULE BODY
		}

	function cfg_var_get
		Gets the value of a configuration variable.
		Takes one argument, the variable name.
		Returns nonzero iff the variable does not exist.
		Returns zero and prints the variable's value to stdout else.

	function cfg_var_set
		Sets the value of a configuration variable.
		Takes two arguments, the variable name and value.
		Returns nonzero iff the variable name is invalid.
		Returns zero and sets the variable's value else.

	function cfg_var_del
		Deletes a configuration variable.
		Takes one argument, the variable name.
		Returns zero iff the variable was found & deleted.

	function cfg_var_list
		Lists all defined configuration variables.
		Takes no arguments.
		Prints each variable's name and value to stdout, as
			VARIABLE_NAME: VALUE
		Iff there are any variables ( or output), returns zero.

	MODULE_DIR=
		Set to the absolute pathname of the "modules" directory.
		Should be set once and readonly.
	MODULE_NAME=
		Set this to the untranslated MODULE_NAME of the module currently running.
	MODULE_PATH=
		Set this to the absolute, translated module filename of the
		module currently running.

We will test your script with modules of our own; you will probably want to use a module of your own to test your script. If you would like to include your modules, please ensure their module/filenames begin with "test_" so that our names don't collide with yours when we test.

Actions of the script:
1. Validate the command-line, as specified above.

2. Load in and validate the contents of the configuration file.

3. Establish an internal representation of the variables defined in the configuration file. Modules must be able to access (get, set, and list) variable values through a single, well-defined API. (You decide how variables are stored and accessed.) This step may be done during step 2, although variable values should not be made available before the entire configuration file has been processed. (That is, if the API were used during step 2, it would emit nothing read from the configuration file yet.)

4. Call into each module in order. This must happen *after* all variables have been defined, even variable definitions are interposed with "module" lines in the configuration file. Ensure that the interface described above in section "Modules" is provided for every module, and that the values of the variables described are accurate.

Discussion:
1. Describe and justify one of the major design decisions you made for this script. (E.g., variable representation, configuration file processing, or path derivation/construction.)

2. What is one example of a situation that could have been handled with built-in functions or features, but that you chose to handle using an external tool? Why did you decide this?

3. What are the scalability characteristics of your script? (E.g., what would happen if a configuration file with millions of variables were passed to it, or if it were used with a large number of modules?)

4. What reasons are there for including module scripts in core, instead of executing them directly as separate processes? When might it be better to call them as separate processes?


Question 3:
We need to run a series of programs based on set of dependences of other programs completing. 

1. Describe a file format to store descriptions of workflow dependencies.

2. Assume we have N programs, each with names. For example, five programs named A, B, C, D, and E, with the following interdependences (assume there are no others):

* A depends on nothing
* B depends on A
* C depends on A
* D depends on A
* E depends on B,C, and D

Write a small program in C, C++, or Java that will:
* Read in a configuration file of dependences (based on the format you defined in (1))
* Print the program name in an order such that the dependence structure is satisfied. 
* Print the letters on the same line if they can run in parallel. All programs should be printed out as early as they can run

In the above example, the answer would be:
A
B C D
E

*** extra credit: print the programs on a single line in parallel up until a certain concurrency limit. For example, if we had no concurrency limit, B,C,D could all run at once. However, with a concurrency limit of 2, only two of these programs can run at the same time.
In the above example, the one answer could be:
A
B C
D
E

Again, print the letters.

Question 4:
In this exercise, you will use d3.js to generate a graph on the fly. You are given two datasets:
Dataset 1: Past data
time: time stamp
kpi: value of the key performance indicator at that time
trend: value of the overall trend at that time
threshold: maximum value of the KPI

Dataset 2: Forecasted data
time: time stamp
forecast_trend: forecasted trend for that time
forecast_low: forecasted low for that time
forecast_high: forecasted high for that time
threshold: maximum value of the KPI

The dataset should draw a scatter plot of past data with a black trend line, dashed line plots of forecasted trend (black), low (blue), and high (blue), and a red max threshold over all times. The graph should look like the attached graphic.